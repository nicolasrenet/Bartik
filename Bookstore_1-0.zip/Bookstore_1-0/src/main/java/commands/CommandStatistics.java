package commands;

import javax.servlet.http.HttpServletRequest;

public class CommandStatistics extends Command{
	
	@Override
	public String getOrderName() {
		return "statistics";
	}
	
	@Override
	public Action executeAction(HttpServletRequest req) {
		
		req.setAttribute("average", dao.getStatistics());
		req.setAttribute("size", dao.listByAuthorAsc().size());
		return new Action("Statistics.jsp", false);
	}
}