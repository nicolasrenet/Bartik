package dao;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import beans.Book;


@ApplicationScoped @JSON
public class BookDAOJSONImpl implements BookDAO {

	
	private List<Book> books = new ArrayList<>();
	private ObjectMapper mapper = new ObjectMapper();
	private InputStream stream;
	
	@Inject
	public BookDAOJSONImpl() throws JsonParseException, JsonMappingException, IOException {
		
		this.stream = getClass().getClassLoader().getResourceAsStream("books.json");
		this.books = mapper.readValue(stream, new TypeReference<List<Book>>() {});

	}

	@Override
	public Book find(int it) {
		//look through JSON until we find ID
				for(Book b : books) {
					if(b.getId() == it) {
						return b;
					}
				}
				return null;
	}

	@Override
	public void add(int it, String title, String desc, String author, String price) {
		Book book = new Book(it,title,desc,author,Double.parseDouble(price));
		books.add(book);
		updateFile();
	}

	@Override
	public void modify(int id, String title, String desc, String author, String price) {
		Book book = find(id);
		book.setTitle(title);
		book.setDescription(desc);
		book.setAuthor(author);
		book.setPrice(Double.parseDouble(price));
		updateFile();
		
	}

	@Override
	public void delete(int id) {
		Book book = find(id);
		books.remove(book);
		updateFile();
		
	}

	@Override
	public double getStatistics() {
		if(books.isEmpty()) {
			return 0;
		}
		int size = books.size();
		
		double Prices = 0;
		for(Book book:books){
			double bookPrice = book.getPrice();
			Prices = Prices + bookPrice;
		}
		
		 return (Prices/size);
	}

	private List<Book> list(final String sortkey) {
		return this.books;
	}

	public List<Book> list() {
		return list("yay");
	}

	public List<Book> listByIdAsc() {
		return list("id ASC");
	}

	public List<Book> listByIdDesc() {
		return list("id DESC");
	}

	public List<Book> listByTitleAsc() {
		return list("title ASC");
	}

	public List<Book> listByTitleDesc() {
		return list("title DESC");
	}

	public List<Book> listByPriceAsc() {
		return list("price ASC");
	}

	public List<Book> listByPriceDesc() {
		return list("price DESC");
	}

	@Override
	public List<Book> listByAuthorAsc() {
		return list("author ASC");
	}

	@Override
	public List<Book> listByAuthorDesc() {
		return list("author DESC");
	}
	private void updateFile() {
		String json ="[\t";
		for(Book b:books) {
			try {
				json += mapper.writeValueAsString(b);
				if(b == books.get(books.size()-1)) {
					json +="\n";
				}
				else{
					json +=",\n";
				}
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
		}
		try {
						
			//writes to Glassfish's domain/domain1/eclipseApps/Bookstore1_0/web_INF/Classes/books.json
			File file = new File(getClass().getClassLoader().getResource("books.json").toURI());
			FileWriter write = new FileWriter(file, false);
			BufferedWriter writer = new BufferedWriter(write);
			writer.append(json);
			writer.append("]");
			System.out.println("Written");
			writer.close();
			
		
		} catch (IOException e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
