package dao;

 //Uncomment for use

 import org.junit.jupiter.api.*;
 
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import beans.Book;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.List;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class BookDAOJSONImplTest {

	 @Test
	 void myTestMethod(){
	    assertEquals(1,1);
	 }
	 @Test
	 @Order(1)
	 void myJSONFindTest() throws JsonParseException, JsonMappingException, IOException {
		 BookDAOJSONImpl test = new BookDAOJSONImpl();
		 beans.Book book = test.find(5);
		 assertEquals(book.getAuthor(), "Colette");
		 
	 }
	 
	 @Test
	 @Order(2)
	 void myJSONListTest() throws JsonParseException, JsonMappingException, IOException{
		 BookDAOJSONImpl test = new BookDAOJSONImpl();
		 List<Book> list= test.list();
		 assertEquals(list.size(),5);
	 }
	 
	 @Test
	 @Order(3)
	 void myJSONAddTest() throws JsonParseException, JsonMappingException, IOException {
		 BookDAOJSONImpl test = new BookDAOJSONImpl();
		 test.add(6, "brian", "cool", "brian", "69");
		 Book mybook = test.find(6);
		 assertEquals(mybook.getAuthor(),"brian");
	 }
	 
	 @Test
	 @Order(4)
	 void myJSONEditTest() throws JsonParseException, JsonMappingException, IOException {
		 BookDAOJSONImpl test = new BookDAOJSONImpl();
		 test.modify(6, "brian", "cool", "brian", "70");
		 Book mybook = test.find(6);
		 assertEquals(mybook.getPrice(),70);
	 }
	 
	 @Test
	 @Order(5)
	 void myJSONDeleteTest() throws JsonParseException, JsonMappingException, IOException {
		 BookDAOJSONImpl test = new BookDAOJSONImpl();
		 test.delete(6);
		 Book mybook = test.find(6);
		 assertEquals(mybook,null);
	 }
	 
	 @Test
	 @Order(6)
	 void myJSONListAfterTest() throws JsonParseException, JsonMappingException, IOException{
		 BookDAOJSONImpl test = new BookDAOJSONImpl();
		 List<Book> list= test.list();
		 assertEquals(list.size(),5);
	 }
}
